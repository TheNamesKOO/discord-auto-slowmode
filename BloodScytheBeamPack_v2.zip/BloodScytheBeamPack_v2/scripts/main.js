import { world, system } from "@minecraft/server";

const ARTIFACT_ID = "artifact:zeus_scythe";
const PRIMARY_COOLDOWN = 30 * 20; // 30s
const SECONDARY_COOLDOWN = 60 * 20; // 60s

const primaryCooldowns = new Map();
const secondaryCooldowns = new Map();

function updateActionBar(player) {
    const now = system.currentTick;
    const pCD = primaryCooldowns.get(player.id);
    const sCD = secondaryCooldowns.get(player.id);
    let msg = "";

    if (pCD && now < pCD) msg += `§bOne: §f${Math.ceil((pCD-now)/20)}s`;
    else msg += `§aOne: Ready`;
    msg += " §7| ";
    if (sCD && now < sCD) msg += `§bTwo: §f${Math.ceil((sCD-now)/20)}s`;
    else msg += `§aTwo: Ready`;

    player.onScreenDisplay.setActionBar(msg);
}

system.runInterval(() => {
    for (const player of world.getPlayers()) updateActionBar(player);
}, 20);

world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    const item = event.itemStack;
    if (!item || item.typeId !== ARTIFACT_ID) return;
    const now = system.currentTick;
    const pCD = primaryCooldowns.get(player.id);
    if (pCD && now < pCD) {
        player.sendMessage("§cArtifact Gods: You can't use that ability due to your 30 second cooldown");
        return;
    }
    primaryCooldowns.set(player.id, now + PRIMARY_COOLDOWN);
    player.runCommandAsync('tag @s add zeus_1');
    updateActionBar(player);
});

world.afterEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const item = event.itemStack;
    if (!item || item.typeId !== ARTIFACT_ID || !player.isSneaking) return;
    const now = system.currentTick;
    const sCD = secondaryCooldowns.get(player.id);
    if (sCD && now < sCD) {
        player.sendMessage("§cArtifact Gods: You can't use that ability due to your 60 second cooldown");
        return;
    }
    secondaryCooldowns.set(player.id, now + SECONDARY_COOLDOWN);
    player.runCommandAsync('tag @s add zeus_2');
    updateActionBar(player);
});